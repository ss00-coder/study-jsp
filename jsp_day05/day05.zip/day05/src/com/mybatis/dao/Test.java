package com.mybatis.dao;

import com.mybatis.vo.MemberVO;

public class Test {
	public static void main(String[] args) {
		MemberDAO memberDAO = new MemberDAO();
		MemberVO memberVO = memberDAO.select(2L);
		
		memberVO.setMemberName("이순신");
		
		memberDAO.update(memberVO);
		
//		memberDAO.delete(3L);
		
//		System.out.println(memberDAO.select(2L));
		
//		System.out.println(memberDAO.getCountOfMemberName("한동석"));
		
//		memberDAO.selectAll().forEach(System.out::println);
		
//		MemberVO memberVO = new MemberVO();
//		memberVO.setMemberName("김보령");
//		memberVO.setMemberAge(99);
//		
//		memberDAO.insert(memberVO);
	}
}
